from django.contrib import admin

from .models import AboutUs, Rules

# Register your models here.
admin.site.register(Rules)
admin.site.register(AboutUs)
